from django.db import models


class Customer(models.Model):
    name = models.CharField(max_length=50)
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=600)

    def __str__(self):
        return self.name

    def register(self):
        self.save()

    def isExists(self):
        if(Customer.objects.filter(username=self.username)):
            return True
        else:
            return False

    @staticmethod
    def get_username(username):
        # return Customer.objects.filter(username=username)   we wont use filter because it returns a list and we want single
        try:
            return Customer.objects.get(username=username)
        except:
            return False
