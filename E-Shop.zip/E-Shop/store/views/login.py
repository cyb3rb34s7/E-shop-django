from django.shortcuts import render, redirect
from django.http import HttpResponse

from store.models.customer import Customer
from django.contrib.auth.hashers import check_password
from django.views import View


class Login(View):
    return_url = None

    def get(self, request):
        Login.return_url = request.GET.get('return_url')
        return render(request, 'login.html')

    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        customer = Customer.get_username(username)
        error_message = None

        if customer:
            flag = check_password(password, customer.password)
            request.session['user_id'] = customer.id
            # saving user session

            if flag:
                if Login.return_url:
                    return redirect('orders')
                else:
                    return redirect('homepage')
            else:
                error_message = "Email or Password Is invalid"
        else:
            error_message = "Email or Password Is invalid"
        print('you are')
        return render(request, 'login.html', {'error': error_message})


def logout(request):
    request.session.clear()
    return redirect('homepage')
