from django.shortcuts import render, redirect
from django.http import HttpResponse

from store.models.customer import Customer
from django.contrib.auth.hashers import check_password
from django.views import View
from store.models.product import Product
from store.models.order import Order


class Cart(View):
    def get(self, request):
        # yaha product ki ids fetch ho gyi list form m, ab in list ko product m bhejo taaki naam mil jaaye
        # print(list(request.session.get('cart').keys()))
        ids = (list(request.session.get('cart').keys()))
        products = Product.get_products_cart(ids)
        print(products)
        return render(request, 'cart.html', {'cart_products': products})


class Checkout(View):
    def post(self, request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('user_id')
        cart = request.session.get('cart')
        products = Product.get_products_cart(list(cart.keys()))
        print(address, phone, customer, products)
        for product in products:
            order = Order(user=Customer(id=customer),
                          product=product,
                          quantity=cart.get(str(product.id)),
                          price=product.price,
                          address=address
                          )
            order.placeOrder()
        request.session['cart'] = {}
        return redirect('cart')
