from django.shortcuts import render, redirect
from django.http import HttpResponse

from store.models.customer import Customer
from django.contrib.auth.hashers import check_password
from django.views import View
from store.models.product import Product
from store.models.order import Order
from store.middlewares.auth import auth_user


class OrderView(View):

    def get(self, request):
        customer = request.session.get('user_id')
        orders = Order.get_orders_by_user_ID(customer)
        print(customer, orders)
        return render(request, 'orders.html', {'orders': orders})
