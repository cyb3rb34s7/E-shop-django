from django.shortcuts import render, redirect
from django.http import HttpResponse

from store.models.customer import Customer
from django.contrib.auth.hashers import make_password, check_password
from django.views import View


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        name = postData.get('name')
        username = postData.get('username')
        password = postData.get('password')

        customer = Customer(
            name=name, username=username, password=password)
        values = {
            'name': name,
            'username': username

        }
        error_message = self.validateUser(customer)
        if(not error_message):
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('login')
        else:
            data = {
                'error': error_message,
                'values': values
            }
            return render(request, 'signup.html', data)

    def validateUser(self, customer):
        error_message = None
        if(not customer.name):
            error_message = "Name is a required Field"
        if(not customer.username):
            error_message = "UserName is a required Field"

        if(not customer.password):
            error_message = "Password is a required Field"
        elif(len(customer.password) < 6):
            error_message = "Password Must be at Least 6 characters long"

        elif(customer.isExists()):
            error_message = "Username Is already registered"

        return error_message
